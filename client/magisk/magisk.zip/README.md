本仓库代码来源为 [sleepyclient-magisk](https://github.com/sleepy-project/sleepy/tree/main/client/magisk)，稍微进行了修改。鸣谢@kmizmal

# 配置

> [!TIP]
> by [kmizmal](https://github.com/kmizmal) <br/>
> 由 wyf9 小修本文的格式
配置文件在`config.cfg`  
`URL` 和 `SECRET` 自己看着填 ***(必填)***

`GAME_PACKAGES` 里可以填游戏包名（空格分隔，双引号包裹），延长玩游戏时的请求间隔*选填*

> 默认 **非游戏** `30s` 检查一次，*玩游戏*时 ~~`600s`~~ 10 分钟检查一次

有特殊需求的自己去 `service.sh` 里面的 `is_game()` 找 **30** 和 **600** 改

# 一些说明

因为我不会把 app 包名转换为 app 名称，所以借小米应用商店用了一下，名称解析的结果都会保存到 cache.txt，因为小米应用商店的限制，部分应用还是获取不到名称，可以在 cache.txt 里面手动指定,格式: `包名=名称`

`getprop ro.product.model` 获取出来的是设备型号，可能与你理解的不太一样，可以在`config.cfg` 里指定设备显示名称

理论上锁屏时间超过半个小时发送未使用（实际上因为锁屏导致的进程休眠，实际触发大概需要两个小时），可以在service.sh的~~大概~~122行修改，自行测试

> md文档可能没有脚本更新及时，因为我~~可能会忘记~~ 懒

*日志写在 `monitor.log`，可以在抽风的时候检查一下*

> [!NOTE]
> **`monitor.log` 每次重启都会清空**
